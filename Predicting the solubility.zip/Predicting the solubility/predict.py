# Using Python 3.7.3
import numpy as np
import pandas as pd
from rdkit.Chem import Descriptors
from rdkit import Chem
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import r2_score
import pickle

def predict_fun(filename): # Define the predicting function.
	inputname = './input/' + filename + '.xlsx'
	df = pd.read_excel(inputname)
	fps = df.iloc[:, [1, 2, 3, 5, 6, 7]].values
	temperature = df['Temperature'].values.reshape(len(df['Temperature'].values), 1)
	X_pred = np.append(fps, temperature, axis=1)
	X_pred_std = sc.transform(X_pred)
	y_pred = model.predict(X_pred_std)
	
	# save data
	outputname = filename + '.txt'
	np.savetxt(outputname, y_pred)

# load standardscaler and model
sc = pickle.load(open('./model/sc.pkl', 'rb'))
model = pickle.load(open('./model/finalized_model.sav', 'rb'))

# predict PCBM in common 42 solvent
predict_fun('PCBM_common_solvent')
# predict PCBM in all solvent in dataset
predict_fun('PCBM_all_solvent')
# predict Y6 in common 42 solvent
predict_fun('Y6_common_solvent')
# predict Y6 in all solvent in dataset
predict_fun('Y6_all_solvent')
